<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ONLINE BLOOD BANK</title>
    <link rel="stylesheet" href="welcome.css">
    <h1>DONATE BLOOD SAVE LIFE</h1>
</head>
<body>
<h3>Every drop counts!</h3> 
<a href="login.php">join with us</a>
<div class="register-link">
    <p>FREQUENTLY ASKED QUESTIONS
    <a href="faqs.html">know more</a></p>
</div>  
</body>
</html>
